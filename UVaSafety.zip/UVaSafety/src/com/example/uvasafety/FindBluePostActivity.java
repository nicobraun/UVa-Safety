package com.example.uvasafety;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import com.example.uvasafety.R;
import com.example.uvasafety.Report;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class FindBluePostActivity extends Activity{
	ListView bluePostList;
	Button enterBluePostQueryButton;
	Button mapDisplayButton;
	private EditText bluePostQueryEditText;
	String webserviceURL = "http://phase3turnip.azurewebsites.net/";
	ArrayList<BluePost> values;
	ArrayAdapter<BluePost> adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d("onCreate", "start up");
		setContentView(R.layout.activity_blue);
		initView("");
		bluePostQueryEditText = (EditText) findViewById(R.id.blueQueryEditText);
		enterBluePostQueryButton = (Button) findViewById(R.id.enterBlueQueryButton);
		enterBluePostQueryButton.setOnClickListener(enterBlueQueryButtonListener);
		mapDisplayButton = (Button) findViewById(R.id.mapActivityButton);
		mapDisplayButton.setOnClickListener(mapDisplayButtonListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void initView(String keyword) {
		bluePostList = (ListView) findViewById(R.id.bluePostList);
		values = new ArrayList<BluePost>();

		// Adjust the URL with the appropriate parameters
		String url = webserviceURL + keyword;

		Log.d("HTTP", url);
		adapter = new ArrayAdapter<BluePost>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1, values);

		// Assign adapter to ListView
		bluePostList.setAdapter(adapter);

		new GetPostTask().execute(url);

	}

	public static String getJSONfromURL(String url) {

		// initialize
		InputStream is = null;
		String result = "";

		// http post
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(url);
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		} catch (Exception e) {
			Log.e("BluePostSearch", "Error in http connection " + e.toString());
		}

		// convert response to string
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (Exception e) {
			Log.e("BluePostSearch", "Error converting result " + e.toString());
		}

		return result;
	}

	// The definition of our task class
	private class GetPostTask extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
		}

		@Override
		protected String doInBackground(String... params) {
			String url = params[0];
			ArrayList<BluePost> lbp = new ArrayList<BluePost>();

			try {

				String webJSON = getJSONfromURL(url);
				
				Log.d("JSON", webJSON);
				Gson gson = new Gson();

				JsonParser parser = new JsonParser();
				JsonArray Jarray = parser.parse(webJSON).getAsJsonArray();

				for (JsonElement obj : Jarray) {
					BluePost pst = gson.fromJson(obj, BluePost.class);
					Log.d("POST", pst.toString());
					lbp.add(pst);
				}
				

			} catch (Exception e) {
				Log.e("BluePostSearch", "JSONPARSE:" + e.toString());
			}

			values.clear();
			values.addAll(lbp);

			return "Done!";
		}

		@Override
		protected void onProgressUpdate(Integer... ints) {

		}

		@Override
		protected void onPostExecute(String result) {
			// tells the adapter that the underlying data has changed and it
			// needs to update the view
			adapter.notifyDataSetChanged();
		}
	}
	
	public OnClickListener enterBlueQueryButtonListener = new OnClickListener(){

		@Override
		public void onClick(View theView) {
			
			// If there is a stock symbol entered into the EditText
			// field
			if(bluePostQueryEditText.getText().length() > 0){
								
//				queryEditText.setText(""); // Clear EditText box
				
				// Force the keyboard to close
				InputMethodManager imm = (InputMethodManager)getSystemService(
					      Context.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(bluePostQueryEditText.getWindowToken(), 0);

	            //TextView enterQueryTextView = (TextView) findViewById(R.id.enterQueryTextView);
	            String keyword = bluePostQueryEditText.getText().toString();
	            initView(keyword);
	            
			} else {
				
			}
			
		}
		
	};
	
	public OnClickListener mapDisplayButtonListener = new OnClickListener(){

		@Override
		public void onClick(View theView) {
			
			Intent intent = new Intent(FindBluePostActivity.this, MapActivity.class);
            startActivity(intent);  
			
		}
		
	};
}
