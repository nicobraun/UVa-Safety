package com.example.uvasafety;

import android.app.Activity;
import android.os.Bundle;


public class MapActivity extends Activity {
	TouchImageView img;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        img = (TouchImageView) findViewById(R.id.mapsImageView);
        img.setMaxZoom(4);
    }
}