package com.example.uvasafety;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import com.example.uvasafety.R;
import com.example.uvasafety.Student;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class FindStudentsActivity extends Activity{
	ListView hoursList;
	Button enterGreenQueryButton;
	private EditText greenQueryEditText;
	String webserviceURL = "http://hoosyourbuddy.herokuapp.com/";
	ArrayList<Student> values;
	ArrayAdapter<Student> adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d("onCreate", "start up");
		setContentView(R.layout.activity_students);
		initView("");
		greenQueryEditText = (EditText) findViewById(R.id.greenQueryEditText);
		enterGreenQueryButton = (Button) findViewById(R.id.enterGreenQueryButton);
		enterGreenQueryButton.setOnClickListener(enterGreenQueryButtonListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void initView(String keyword) {
		hoursList = (ListView) findViewById(R.id.hoursList);
		values = new ArrayList<Student>();

		// Adjust the URL with the appropriate parameters
		String url = webserviceURL + keyword;

		Log.d("HTTP", url);
		adapter = new ArrayAdapter<Student>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1, values);

		// Assign adapter to ListView
		hoursList.setAdapter(adapter);

		new GetPostTask().execute(url);

	}

	public static String getJSONfromURL(String url) {

		// initialize
		InputStream is = null;
		String result = "";

		// http post
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpGet httppost = new HttpGet(url);
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		} catch (Exception e) {
			Log.e("Student", "Error in http connection " + e.toString());
		}

		// convert response to string
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (Exception e) {
			Log.e("Student", "Error converting result " + e.toString());
		}

		return result;
	}

	// The definition of our task class
	private class GetPostTask extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
		}

		@Override
		protected String doInBackground(String... params) {
			String url = params[0];
			ArrayList<Student> lbp = new ArrayList<Student>();

			try {

				String webJSON = getJSONfromURL(url);
				
				Log.d("JSON", webJSON);
				Gson gson = new Gson();

				JsonParser parser = new JsonParser();
				JsonArray Jarray = parser.parse(webJSON).getAsJsonArray();

				for (JsonElement obj : Jarray) {
					Student pst = gson.fromJson(obj, Student.class);
					Log.d("GET", pst.toString());
					lbp.add(pst);
				}
				

			} catch (Exception e) {
				Log.e("Student", "JSONPARSE:" + e.toString());
			}

			values.clear();
			values.addAll(lbp);

			return "Done!";
		}

		@Override
		protected void onProgressUpdate(Integer... ints) {
	
		}

		@Override
		protected void onPostExecute(String result) {
			// tells the adapter that the underlying data has changed and it
			// needs to update the view
			adapter.notifyDataSetChanged();
		}
	}
	
	public OnClickListener enterGreenQueryButtonListener = new OnClickListener(){

		@Override
		public void onClick(View theView) {
			
			// If there is a stock symbol entered into the EditText
			// field
			if(greenQueryEditText.getText().length() > 0){
								
//				queryEditText.setText(""); // Clear EditText box
				
				// Force the keyboard to close
				InputMethodManager imm = (InputMethodManager)getSystemService(
					      Context.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(greenQueryEditText.getWindowToken(), 0);

	            //TextView enterQueryTextView = (TextView) findViewById(R.id.enterQueryTextView);
	            String keyword = greenQueryEditText.getText().toString();
	            initView(keyword);
	            
			} else {
				
			}
			
		}
		
	};
}
