package com.example.uvasafety;

public class Student {
	public int id;
	public String user_id;
	public String course_dept;
	public int course_num;
	public String title;
	public String desc;
	public String start_time;
	public String loc_id;
	public String end_time;
	public String timestamp;

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Student User ID: " + user_id + "\nCourse Department=" + course_dept + "\nCourse Number: " + course_num + "\nTitle: "  + 
				title + "\nLocation: " + loc_id + "\nStart Time: "  + start_time + "\nEnd Time: " + 
				end_time;
	}
	
	public int getID() {
		return id;
	}
	
	public String getUser() {
		return user_id;
	}

	public String getCourseDept() {
		return course_dept;
	}

	public int getCourseNum() {
		return course_num;
	}

	public String getTitle() {
		return title;
	}

	public String getDesc() {
		return desc;
	}
	
	public String getStartTime() {
		return start_time;
	}
	
	public String getLocation() {
		return loc_id;
	}

	public String getEndTime() {
		return end_time;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setUser(String s) {
		this.user_id = s;
	}
	
	public void setCourseNum(int s) {
		this.course_num = s;
	}
	
	public void setTitle(String s) {
		this.title = s;
	}
	
	public void setStartTime(String s) {
		this.start_time = s;
	}
	
	public void setLocation(String s) {
		this.loc_id = s;
	}
	
	public void setEndTime(String s) {
		this.end_time = s;
	}
	
	public void setTimestamp(String s) {
		this.timestamp = s;
	}
}
