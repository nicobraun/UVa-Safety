package com.example.uvasafety;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;
import android.content.Context;
import android.content.Intent;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import com.example.uvasafety.R;
import com.example.uvasafety.Report;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class MainActivity extends Activity {
	Button redButton;
	Button blueButton;
	Button greenButton;
	Button mapButton;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d("onCreate", "start up");
		setContentView(R.layout.activity_main);
		blueButton = (Button) findViewById(R.id.blueActivityButton);
		blueButton.setOnClickListener(blueButtonListener);
		redButton = (Button) findViewById(R.id.redActivityButton);
		redButton.setOnClickListener(redButtonListener);
		greenButton = (Button) findViewById(R.id.greenActivityButton);
		greenButton.setOnClickListener(greenButtonListener);
		mapButton = (Button) findViewById(R.id.mapActivityButton);
		mapButton.setOnClickListener(mapButtonListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public OnClickListener blueButtonListener = new OnClickListener(){
		
//		final Context context = this;
		
		@Override
		public void onClick(View theView) {
			
			Intent intent = new Intent(MainActivity.this, FindBluePostActivity.class);
            startActivity(intent);   
			
		}
		
	};
	
	public OnClickListener redButtonListener = new OnClickListener(){

//		final Context context = this;
		
		@Override
		public void onClick(View theView) {
			
			Intent intent = new Intent(MainActivity.this, FindPoliceReportActivity.class);
            startActivity(intent);   
			
		}
		
	};
	
	public OnClickListener greenButtonListener = new OnClickListener(){

//		final Context context = this;
		
		@Override
		public void onClick(View theView) {
			
			Intent intent = new Intent(MainActivity.this, FindStudentsActivity.class);
            startActivity(intent);   
			
		}
		
	};
	
	public OnClickListener mapButtonListener = new OnClickListener(){

//		final Context context = this;
		
		@Override
		public void onClick(View theView) {
			
			Intent intent = new Intent(MainActivity.this, MapActivity.class);
            startActivity(intent);   
			
		}
		
	};
	
}
