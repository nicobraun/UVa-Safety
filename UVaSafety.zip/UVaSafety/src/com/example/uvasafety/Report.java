package com.example.uvasafety;

public class Report {
	public int id;
	public String title;
	public String body;
	public String created;
	public String modified;

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Report ID: " + id + "\nTitle: " + title
				+ "\nBody: " + body + "\nCreated: " + created
				+ "\nModified: " + modified;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String mnemonic) {
		this.body = mnemonic;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String number) {
		this.created = number;
	}

	public void setId(int courseID) {
		this.id = courseID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String department) {
		this.title = department;
	}

	public String getModified() {
		return modified;
	}

	public void setModified(String courseName) {
		this.modified = courseName;
	}
}
