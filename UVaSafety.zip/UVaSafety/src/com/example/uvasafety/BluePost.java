package com.example.uvasafety;

public class BluePost {
	public String phoneType;
	public String number;
	public String location;
	public String notes;
	public String csrRef;

	public String getPhonetype() {
		return phoneType;
	}

	@Override
	public String toString() {
		return "Emergency Post Number: " + number
				+ "\nLocation: " + location + "\nNotes: " + notes;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String mnemonic) {
		this.location = mnemonic;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String n) {
		this.notes = n;
	}

	public void setPhoneType(String pt) {
		this.phoneType = pt;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String num) {
		this.number = num;
	}

	public String getCSR() {
		return csrRef;
	}

	public void setCSR(String csr) {
		this.csrRef = csr;
	}
}
